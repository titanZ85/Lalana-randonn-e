package com.mototracker.app

import android.app.Application
import com.google.firebase.database.FirebaseDatabase

class MotoTrackerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        FirebaseDatabase.getInstance().setPersistenceEnabled(true)
    }
}
