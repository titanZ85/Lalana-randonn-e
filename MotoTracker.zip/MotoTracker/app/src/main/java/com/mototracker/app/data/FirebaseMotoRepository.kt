package com.mototracker.app.data

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.mototracker.app.model.Moto

class FirebaseMotoRepository {
    private val root: DatabaseReference = FirebaseDatabase.getInstance().getReference("groupes")

    fun envoyerPosition(groupe: String, moto: Moto) {
        root.child(groupe).child("motos").child(moto.id).setValue(moto)
    }

    fun ecouterGroupe(groupe: String, callback: (List<Moto>) -> Unit): ValueEventListener {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val motos = snapshot.children
                    .mapNotNull { it.getValue(Moto::class.java) }
                    .filter { it.latitude != 0.0 || it.longitude != 0.0 }
                    .take(MAX_MOTOS)
                callback(motos)
            }
            override fun onCancelled(error: DatabaseError) = callback(emptyList())
        }
        root.child(groupe).child("motos").addValueEventListener(listener)
        return listener
    }

    fun quitterGroupe(groupe: String, motoId: String) {
        root.child(groupe).child("motos").child(motoId).removeValue()
    }

    companion object { const val MAX_MOTOS = 60 }
}
