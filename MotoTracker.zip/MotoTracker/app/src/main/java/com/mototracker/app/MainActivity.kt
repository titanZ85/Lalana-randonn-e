package com.mototracker.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.mototracker.app.data.FirebaseMotoRepository
import com.mototracker.app.data.GpxExporter
import com.mototracker.app.model.Moto
import com.mototracker.app.service.LocationService

class MainActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var map: GoogleMap
    private val repository = FirebaseMotoRepository()
    private val groupe = "MOTO47"
    private val motoId = "MOTO-01"
    private val pseudo = "Pilote 1"
    private val typeMoto = "Gros cylindre"

    private val permissions = arrayOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        findViewById<Button>(R.id.btnDemarrer).setOnClickListener {
            if (permissionsOk()) demarrer() else ActivityCompat.requestPermissions(this, permissions, 100)
        }

        findViewById<Button>(R.id.btnExporterGpx).setOnClickListener { exporter() }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        repository.ecouterGroupe(groupe) { afficher(it) }
    }

    private fun afficher(motos: List<Moto>) {
        if (!::map.isInitialized) return
        map.clear()

        motos.forEach { moto ->
            map.addMarker(
                MarkerOptions()
                    .position(LatLng(moto.latitude, moto.longitude))
                    .title(moto.pseudo)
                    .snippet("${moto.typeMoto} • ${moto.vitesseKmh.toInt()} km/h")
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE))
            )
        }

        findViewById<TextView>(R.id.txtMotos).text =
            "Motos connectées : ${motos.size} / ${FirebaseMotoRepository.MAX_MOTOS}"

        motos.firstOrNull { it.id == motoId }?.let {
            findViewById<TextView>(R.id.txtVitesse).text = "Ma vitesse : ${it.vitesseKmh.toInt()} km/h"
            map.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(it.latitude, it.longitude), 15f))
        }
    }

    private fun permissionsOk() = permissions.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun demarrer() {
        ContextCompat.startForegroundService(
            this,
            Intent(this, LocationService::class.java)
                .putExtra("GROUPE", groupe)
                .putExtra("MOTO_ID", motoId)
                .putExtra("PSEUDO", pseudo)
                .putExtra("TYPE_MOTO", typeMoto)
        )
        Toast.makeText(this, "Suivi démarré", Toast.LENGTH_SHORT).show()
    }

    private fun exporter() {
        GpxExporter(this).exporter("Randonnee_$groupe", LocationService.obtenirTrajet())
            .onSuccess { Toast.makeText(this, "GPX exporté : $it", Toast.LENGTH_LONG).show() }
            .onFailure { Toast.makeText(this, "Erreur : ${it.message}", Toast.LENGTH_LONG).show() }
    }
}
