package com.mototracker.app.model

data class TrackPoint(
    val latitude: Double,
    val longitude: Double,
    val altitude: Double? = null,
    val vitesseKmh: Double = 0.0,
    val horodatageMillis: Long
)
