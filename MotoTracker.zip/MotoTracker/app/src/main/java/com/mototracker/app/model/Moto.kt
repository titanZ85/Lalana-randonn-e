package com.mototracker.app.model

data class Moto(
    val id: String = "",
    val pseudo: String = "",
    val typeMoto: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val vitesseKmh: Double = 0.0,
    val capDegres: Double = 0.0,
    val precisionMetres: Double = 0.0,
    val batterie: Int = 100,
    val horodatage: Long = 0L
)
