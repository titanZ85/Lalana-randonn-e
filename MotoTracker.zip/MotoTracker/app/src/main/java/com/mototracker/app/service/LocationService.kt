package com.mototracker.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.mototracker.app.R
import com.mototracker.app.data.FirebaseMotoRepository
import com.mototracker.app.data.GpxExporter
import com.mototracker.app.model.Moto
import com.mototracker.app.model.TrackPoint

class LocationService : Service() {

    private val repository = FirebaseMotoRepository()
    private lateinit var fused: FusedLocationProviderClient
    private var groupe = ""
    private var motoId = ""
    private var pseudo = ""
    private var typeMoto = ""

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val location: Location = result.lastLocation ?: return
            val point = TrackPoint(
                location.latitude, location.longitude,
                if (location.hasAltitude()) location.altitude else null,
                location.speed * 3.6,
                System.currentTimeMillis()
            )
            ajouterPoint(point)

            repository.envoyerPosition(
                groupe,
                Moto(
                    motoId, pseudo, typeMoto,
                    location.latitude, location.longitude,
                    location.speed * 3.6, location.bearing.toDouble(),
                    location.accuracy.toDouble(), 100,
                    System.currentTimeMillis()
                )
            )
        }
    }

    override fun onCreate() {
        super.onCreate()
        fused = LocationServices.getFusedLocationProviderClient(this)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Suivi moto", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        groupe = intent?.getStringExtra("GROUPE") ?: ""
        motoId = intent?.getStringExtra("MOTO_ID") ?: ""
        pseudo = intent?.getStringExtra("PSEUDO") ?: ""
        typeMoto = intent?.getStringExtra("TYPE_MOTO") ?: ""

        if (groupe.isBlank() || motoId.isBlank()) { stopSelf(); return START_NOT_STICKY }

        startForeground(1, notification())
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 4000L)
            .setMinUpdateIntervalMillis(2000L).build()

        fused.requestLocationUpdates(request, callback, Looper.getMainLooper())
        return START_STICKY
    }

    override fun onDestroy() {
        fused.removeLocationUpdates(callback)
        if (groupe.isNotBlank() && motoId.isNotBlank()) repository.quitterGroupe(groupe, motoId)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun notification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("MotoTracker actif")
            .setContentText("Position partagée avec le groupe.")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setOngoing(true)
            .build()

    companion object {
        private const val CHANNEL_ID = "moto_tracker"
        private val trajet = mutableListOf<TrackPoint>()

        fun obtenirTrajet(): List<TrackPoint> = trajet.toList()
        fun ajouterPoint(point: TrackPoint) { trajet.add(point) }
        fun viderTrajet() { trajet.clear() }
    }
}
