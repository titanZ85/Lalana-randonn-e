package com.mototracker.app.data

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.mototracker.app.model.TrackPoint
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class GpxExporter(private val context: Context) {

    fun exporter(nomTrajet: String, points: List<TrackPoint>): Result<String> {
        if (points.isEmpty()) return Result.failure(IllegalStateException("Aucun point GPS."))

        val nom = "MotoTracker_${nomTrajet.replace(Regex("[^A-Za-z0-9_-]"), "_")}_${System.currentTimeMillis()}.gpx"
        return try {
            val uri = creerFichier(nom)
            context.contentResolver.openOutputStream(uri)?.use {
                it.write(construireGpx(nomTrajet, points).toByteArray(Charsets.UTF_8))
                it.flush()
            }
            Result.success(nom)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun construireGpx(nom: String, points: List<TrackPoint>): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        val xml = points.joinToString("\n") { p ->
            val ele = p.altitude?.let { "<ele>$it</ele>" } ?: ""
            val speed = "<speed>${p.vitesseKmh / 3.6}</speed>"
            "<trkpt lat=\"${p.latitude}\" lon=\"${p.longitude}\">$ele<time>${fmt.format(Date(p.horodatageMillis))}</time>$speed</trkpt>"
        }
        return """<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="MotoTracker" xmlns="http://www.topografix.com/GPX/1/1">
<metadata><name>$nom</name><time>${fmt.format(Date())}</time></metadata>
<trk><name>$nom</name><trkseg>$xml</trkseg></trk>
</gpx>"""
    }

    private fun creerFichier(nom: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, nom)
            put(MediaStore.Downloads.MIME_TYPE, "application/gpx+xml")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
        }
        val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Création du fichier impossible")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            context.contentResolver.update(uri, ContentValues().apply {
                put(MediaStore.Downloads.IS_PENDING, 0)
            }, null, null)
        }
        return uri
    }
}
