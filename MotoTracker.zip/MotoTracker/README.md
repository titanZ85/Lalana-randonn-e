# MotoTracker

Application Android de suivi GPS de moto en temps réel.

## Installation
1. Ouvrir le projet dans Android Studio.
2. Ajouter `app/google-services.json` depuis Firebase.
3. Remplacer `VOTRE_CLE_GOOGLE_MAPS` dans `AndroidManifest.xml`.
4. Activer Firebase Realtime Database.
5. Build > Generate Signed App Bundle / APK > APK.

## Fonctions
- Position GPS en temps réel.
- Vitesse de chaque moto.
- Groupes jusqu'à 60 motos.
- Carte Google Maps.
- Export du trajet en GPX.
- Service de suivi en arrière-plan.
